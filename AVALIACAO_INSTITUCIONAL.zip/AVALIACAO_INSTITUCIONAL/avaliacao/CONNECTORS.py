from sqlalchemy.dialects.mysql import pymysql
from pandas import DataFrame
import os
import pymysql


class MySQLConnection:
    def __init__(self, db='aval_institucional'):
        self.metadata = {
            #'andrei_mastro': {'host': 'proddb.clqjwjzpgjhb.sa-east-1.rds.amazonaws.com', 'user': 'andrei_mastro', 'password': 'mWBzW$#F7(wA8j8Y', 'db': 'msprod'},
            # 'andrei_mastro': {'host': os.environ['host'], 'user': os.environ['user'], 'password': 'anima@2019', 'db': os.environ['db']},
            'andrei_mastro': {'host': os.environ['host'], 'user': os.environ['user'], 'password': 'aEtM5ejk3EB!xRM5', 'db': os.environ['db']},
            # 'andrei_mastro': {'host': 'proddb.clqjwjzpgjhb.sa-east-1.rds.amazonaws.com', 'user': 'andrei_mastro', 'password': 'anima@2019', 'db': 'aval_institucional'},
            # 'andrei_mastro': {'host': 'proddb.clqjwjzpgjhb.sa-east-1.rds.amazonaws.com', 'user': 'andrei_mastro', 'password': 'anima@2019', 'db': 'homolog_aval_institucional'},
            'avaliacao': {'host': 'proddb.clqjwjzpgjhb.sa-east-1.rds.amazonaws.com', 'user': 'avaluser', 'password': 'A#MS/=*RYTMdbHJK', 'db': 'msprod'},
            'navihelp': {'host': 'proddb.clqjwjzpgjhb.sa-east-1.rds.amazonaws.com', 'user': 'navihelpuser', 'password': 'DmHSG#$ZEJR(SnR4', 'db': 'msprod'}
        }
        self.md = self.metadata[db]
        self.connection = pymysql.connect(host=self.md['host'], user=self.md['user'], password=self.md['password'], charset='utf8mb4', cursorclass=pymysql.cursors.DictCursor)

    def get_cursor(self):
        cursor = None
        try:
            cursor = self.connection.cursor()
        except Exception as e:
            print(str(e))
            #warning('CONNECTORS', 2, '[MySQLConnection] get_cursor.', e)
        return cursor

    def get_each_df(self, query_str):
        df = DataFrame()
        result = []
        try:
            cursor = self.get_cursor()
            cursor.execute(query_str)
            for row in cursor:
                result.append(row)
            df = DataFrame(result, columns=[i[0] for i in cursor.description])
            self.connection.commit()
            self.connection.close()
        except Exception as e:
            print(str(e))
            #warning('CONNECTORS', 2, '[MySQLConnection] get_each_df.', e)
        return df

    def get_df(self, query_str):
        df = DataFrame()
        try:
            cursor = self.get_cursor()
            cursor.execute(query_str)
            result = cursor.fetchall()
            df = DataFrame(result, columns=[i[0] for i in cursor.description])
            self.connection.commit()
            self.connection.close()
        except Exception as e:
            print(str(e))
            #warning('CONNECTORS', 2, '[MySQLConnection] get_df.', e)
        return df

    def execute(self, query_str):
        success = False
        try:
            cursor = self.get_cursor()
            cursor.execute(query_str)
            self.connection.commit()
            self.connection.close()
            success = True
        except Exception as e:
            print(str(e))
            #warning('CONNECTORS', 2, '[MySQLConnection] execute.', e)
        return success

    def query(self, string, dataframe=False):
        success = False
        result = []
        try:
            cursor = self.get_cursor()
            cursor.execute(string)
            for row in cursor:
                result.append(row)
            success = True
        except Exception as e:
            print(str(e))
            #warning('CONNECTORS', 2, '[MySQLConnection] query.', e)
        return success, result
