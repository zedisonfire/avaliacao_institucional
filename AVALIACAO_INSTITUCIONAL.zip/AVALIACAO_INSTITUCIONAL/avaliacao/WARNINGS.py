﻿from sys import exc_info
import datetime as dt


def warning(weight=0, content='', exception=None):
    content = str(content).replace("'", '')
    try:
        print('[' + str(weight) + '][' + str(dt.datetime.now()) + '][FalaIes] ' + content)
    except Exception as e:
        exc_type, exc_obj, exc_tb = exc_info()
        error_msg = ' '.join([str(exc_tb.tb_lineno), str(exc_type), str(e)])
        print('[3][' + str(dt.datetime.now()) + '][FalaIes] ' + content + error_msg)


# def warning(service='', weight=0, content='', exception=None, log=True, sms=False, email=False, sms_to='', email_to=''):
#     import sys
#     success = False
#     try:
#         content = str(content).replace("'", '')
#         if sys.exc_info() != (None, None, None):
#             exc_type, exc_obj, exc_tb = sys.exc_info()
#             content = str(content) + '.' + ' '.join([' See line', str(exc_tb.tb_lineno), str(exc_type), str(exception)])
#         log_sent = insert_log(service=service, weight=weight, content=content) if log else False
#         sms_sent = send_sms(msg=content, recipient=str(sms_to)) if sms else False
#         email_sent = send_email(msg=content, recipient=str(email_to)) if email else False
#         sent = ' (' + str(log_sent) + ') (' + str(sms_sent) + ') (' + str(email_sent) + ')'
#         print('[' + str(weight) + '][' + str(service) + '] ' + content + sent)
#         success = True
#     except Exception as e:
#         exc_type, exc_obj, exc_tb = sys.exc_info()
#         print('[3][WARNINGS]' + ' '.join(['See line', str(exc_tb.tb_lineno), str(exc_type), str(e)]))
#     return success
#
#
# def insert_log(service='TESTE', weight=0, content=''):
#     import pypyodbc
#     success = False
#     cmd = ''
#     try:
#         content = str(content).replace("'", '')
#         cmd = '''INSERT INTO NAVI_SERVICES_LOG(MODEL, WEIGHT, TIME, TEXT) values('{{service}}', '{{weight}}', GETDATE(), '{{content}}')'''
#         cmd = cmd.replace('{{service}}', str(service))
#         cmd = cmd.replace('{{weight}}', str(weight))
#         cmd = cmd.replace('{{content}}', str(content))
#         db = 'Driver={SQL Server};Server=192.168.173.20;Database=prediction;uid=integracao_navi;pwd=aNqR4ZtYH4rqRWRa'
#         connection = pypyodbc.connect(db)
#         connection.cursor().execute(cmd)
#         connection.commit()
#         connection.close()
#         success = True
#     except Exception as e:
#         warning('WARNINGS', 2, 'insert_log' + str(cmd), e, log=False)
#     return success
#
#
# def send_sms(msg='', recipient='+5511955007132'):
#     from twilio.rest import Client
#     success = False
#     try:
#         track_url = 'http://requestbin.fullcontact.com/134rst71'
#         client = Client('AC96a56b5774be68159f2e526ef58dfc2e', 'b06495a77524c4f70e1813daa77aaa6c')
#         client.messages.create(from_='+18084271937', to=recipient, status_callback=track_url, body=msg)
#         success = True
#     except Exception as e:
#         warning('WARNINGS', 2, 'send_sms', e)
#     return success
#
#
# def send_email(msg='', recipient='navi@animaeducacao.com.br'):
#     import smtplib
#     success = False
#     try:
#         server = smtplib.SMTP('smtp.office365.com', 587)
#         server.ehlo()
#         server.starttls()
#         server.ehlo()
#         server.login('navi@animaeducacao.com.br', 'anima@2017')
#         server.sendmail('navi@animaeducacao.com.br', recipient, '\n' + msg)
#         server.quit()
#         success = True
#     except Exception as e:
#         warning('WARNINGS', 2, 'send_email', e)
#     return success
