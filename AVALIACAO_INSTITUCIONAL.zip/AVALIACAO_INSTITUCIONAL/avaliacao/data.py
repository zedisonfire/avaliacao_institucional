#from AVALIACAO_INSTITUCIONAL.avaliacao.CONNECTORS import *
from .CONNECTORS import *
from cryptography.fernet import Fernet
import base64
import logging
import traceback
from django.conf import settings
import pandas as pd
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
import inspect, os
from .WARNINGS import *
import os


schema = os.environ['schema']
#schema = 'homolog_aval_institucional'
#schema = 'aval_institucional'
#schema = 'dev_andrei'


def get_ies_name_by_id(id):
    id = int(id)
    if id in [3, 4, 6, 9, 10, 11, 19, 20, 21, 22, 46, 49, 50, 51]:
        return 'UNA'
    if id in [1]:
        return 'UNIBH'
    if id in [12, 13, 15, 16, 17, 45]:
        return 'UNISOCIESC'
    if id in [5, 8]:
        return 'USJT'
    return 'USJT'


def access():
    #return open('D:/Reporting/NAVI/access.txt', 'r').readlines()
    return ['navi@animaeducacao.com.br', 'anima@2017', 'smtp.office365.com', '587']


def send_email(message, receipt, subject):
    msg = MIMEMultipart()
    msg['Subject'] = subject
    msg['From'] = access()[0].strip()
    msg['To'] = receipt

    body = MIMEText(message, 'html')
    msg.attach(body)
    server = smtplib.SMTP(access()[2].strip(), access()[3].strip())
    server.ehlo()
    server.starttls()
    server.ehlo()
    server.login(access()[0].strip(), access()[1].strip())
    server.sendmail(msg['From'], receipt, msg.as_string())
    server.quit()


def validate_user(params):
    return True


def encrypt(txt):
    try:
        # convert integer etc to string first
        txt = str(txt)
        # get the key from settings
        cipher_suite = Fernet(settings.ENCRYPT_KEY) # key should be byte
        # #input should be byte, so convert the text to byte
        encrypted_text = cipher_suite.encrypt(txt.encode('ascii'))
        # encode to urlsafe base64 format
        encrypted_text = base64.urlsafe_b64encode(encrypted_text).decode("ascii")
        return encrypted_text
    except Exception as e:
        # log the error if any
        logging.getLogger("error_logger").error(traceback.format_exc())
        return None


def decrypt(txt):
    try:
        # base64 decode
        txt = base64.urlsafe_b64decode(txt)
        cipher_suite = Fernet(settings.ENCRYPT_KEY)
        decoded_text = cipher_suite.decrypt(txt).decode("ascii")
        return decoded_text
    except Exception as e:
        # log the error
        logging.getLogger("error_logger").error(traceback.format_exc())
        return None


def get_structures():
    return {
        'presencial': {
            0: 3,
            1: 6
        },
        'hybrid': {
            0: 3,
            1: 8,
        },
        'infrastructure': {
            0: 8,
            1: 4,
            2: 1,
            3: 1,
        },
        'service': {
            0: 4,
            1: 7,
            2: 3,
            3: 2,
            4: 3,
            5: 1,
            6: 1,
            7: 3,
            8: 1,
            9: 1,
        }
    }


def crop_long_words(value):
    return value[:20] + '...' if len(value) > 20 else value


def format_teacher_name(value):
    return (value[0].lstrip().rstrip() + '-(' + value[-1].lstrip().rstrip() + ')').title()


def split_by_delimiter(value, delimiter):
    return value.replace('-', '').split(delimiter)


def insert_validated_teachers(questionary, teachers_list, params):
    structure = get_structures()
    if questionary == 'presencial':
        questionary_id = 0
    else:
        questionary_id = 1
    answers_params = list()
    progress_params = list()
    for i in structure[questionary]:
        for j in range(0, structure[questionary][i]):
            for teacher in teachers_list:
                params = [
                    params[0],
                    params[1],
                    params[2],
                    questionary_id,  # cod_questionary
                    questionary,  # txt_questionary
                    i,  # cod_main_question
                    j,  # cod_inner_question
                    teacher.split('__')[0],
                    teacher.split('__')[1],
                    teacher.split('__')[2],
                    teacher.split('__')[3]
                ]
                answers_params.append(params)
    for teacher in teachers_list:
        params = [
            params[0],
            params[1],
            params[2],
            teacher.split('__')[0],
            teacher.split('__')[1],
            teacher.split('__')[2],
            teacher.split('__')[3]
        ]
        progress_params.append(params)
    build_query_and_insert('answers', answers_params)
    build_query_and_insert('progress', progress_params)


def validate_teachers(db, presencial_teachers, hybrid_teachers, params):
    df = db[['txt_teacher_name', 'txt_discipline_name', 'txt_teacher_type', 'txt_discipline_type']]
    size = len(df)
    df.fillna('', inplace=True)
    is_empty = 0
    for i in range(0, len(df)):
        if df.loc[i, 'txt_teacher_name'] == '' and df.loc[i, 'txt_discipline_name'] == '' and df.loc[i, 'txt_teacher_type'] == '' and df.loc[i, 'txt_discipline_type'] == '':
            is_empty += 1
    if size == is_empty or is_empty >= size:
        return db
    if not df.empty:
        df.drop_duplicates(inplace=True)
        df.reset_index(inplace=True)
        to_process = list()
        saved_hybrid = list()
        saved_presencial = list()
        new_data = False
        for i in range(0, len(df)):
            if df.loc[i, 'txt_teacher_type'] == 'PRESENCIAL':
                saved_presencial.append(df.loc[i, 'txt_teacher_name'] + '__' + df.loc[i, 'txt_discipline_name'] + '__' + df.loc[i, 'txt_teacher_type'] + '__' + df.loc[i, 'txt_discipline_type'])
            elif df.loc[i, 'txt_teacher_type'] == 'ONLINE':
                saved_hybrid.append(df.loc[i, 'txt_teacher_name'] + '__' + df.loc[i, 'txt_discipline_name'] + '__' + df.loc[i, 'txt_teacher_type'] + '__' + df.loc[i, 'txt_discipline_type'])
        for teacher in presencial_teachers:
            if teacher not in saved_presencial:
                to_process.append(teacher)
                new_data = True
        if len(to_process) > 0:
            insert_validated_teachers('presencial', to_process, params)
        to_process = list()
        for teacher in hybrid_teachers:
            if teacher not in saved_hybrid:
                to_process.append(teacher)
                new_data = True
        if len(to_process) > 0:
            insert_validated_teachers('hybrid', to_process, params)
        if new_data:
            return get_alumn_data([params[0], params[1]])
    return db


def presencial(db, ra='', selected=True):
    presencial = []
    if selected:
        df = db.loc[(db['txt_teacher_type'] == 'PRESENCIAL') & (db['txt_discipline_type'] == 'PRESENCIAL') & (db['txt_teacher_name'] != 'A Contratar')]
        df = df[['txt_teacher_name', 'txt_discipline_name']]
        if df.empty:
            return presencial
        df.drop_duplicates(inplace=True)
        df.reset_index(inplace=True)
        for i in range(0, len(df)):
            presencial.append(df.loc[i, 'txt_teacher_name'] + '__' + df.loc[i, 'txt_discipline_name'])
    else:
        # if not contract:
        df = db.loc[(db['MATRICULA'] == ra) & (db['TIPO_PROFESSOR'] == 'PRESENCIAL') & (db['PROFESSOR'] != 'A Contratar')]# & (db['IND_HIBRIDA'] == 'N')]
        # else:
        #     df = db.loc[(db['MATRICULA'] == ra) & (db['TIPO_PROFESSOR'] == 'PRESENCIAL')]# & (db['IND_HIBRIDA'] == 'N')]
        if df.empty:
            return presencial
        df.reset_index(inplace=True)
        for i in range(0, len(df)):
            presencial.append(df.loc[i, 'PROFESSOR'] + '__' + df.loc[i, 'DISCIPLINA'] + '__PRESENCIAL__PRESENCIAL')
    return presencial


def hybrid(db, ra='', selected=True):
    hybrid = []
    if selected:
        df = db.loc[(db['txt_teacher_type'] == 'ONLINE') & (db['txt_discipline_type'] == 'HYBRID') & (db['txt_teacher_name'] != 'A Contratar')]
        if df.empty:
            return hybrid
        df = df[['txt_teacher_name', 'txt_discipline_name']]
        df.drop_duplicates(inplace=True)
        df.reset_index(inplace=True)
        for i in range(0, len(df)):
            hybrid.append(df.loc[i, 'txt_teacher_name'] + '__' + df.loc[i, 'txt_discipline_name'])
    else:
        # if not contract:
        df = db.loc[(db['MATRICULA'] == ra) & (db['TIPO_PROFESSOR'] == 'ONLINE') & (db['PROFESSOR'] != 'A Contratar')]# & (db['IND_HIBRIDA'] == 'S')]
        # else:
        #     df = db.loc[(db['MATRICULA'] == ra) & (db['TIPO_PROFESSOR'] == 'ONLINE')]# & (db['IND_HIBRIDA'] == 'S')]
        if df.empty:
            return hybrid
        df.reset_index(inplace=True)
        for i in range(0, len(df)):
            hybrid.append(df.loc[i, 'PROFESSOR'] + '__' + df.loc[i, 'DISCIPLINA'] + '__ONLINE__HYBRID')
    return hybrid


def get_progress_data(params):
    try:
        cmd = "SELECT * FROM " + schema + ".Progress WHERE RA = {{RA}} AND COD_IES = {{COD_IES}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
        cmd = cmd.replace("{{COD_IES}}", str(float(params[1])))
        return get_connection().get_df(cmd)
    except:
        pass
    return False


def build_saved_progress_data(params):
    df = get_progress_data(params)
    data = {}
    df.fillna(0, inplace=True)
    df_tmp = df.iloc[0]
    data['total_progress'] = str(round(df_tmp['total_progress']))[:4]
    data['infrastructure_progress'] = str(round(df_tmp['infrastructure_progress']))[:4]
    data['service_progress'] = str(round(df_tmp['service_progress']))[:4]
    presencial_teachers = presencial(df)
    hybrid_teachers = hybrid(df)
    if len(presencial_teachers) > 0:
        for teacher in presencial_teachers:
            df_tmp = df.loc[df['txt_teacher_name'] == teacher.split('__')[0]]
            df_tmp = df_tmp.iloc[0]
            data['presencial_' + format_tag(teacher.split('__')[0] + '__' + format_tag(teacher.split('__')[1])) + '_progress'] = str(round(df_tmp['teacher_progress']))[:4]
    if len(hybrid_teachers) > 0:
        for teacher in hybrid(df):
            df_tmp = df.loc[df['txt_teacher_name'] == teacher.split('__')[0]]
            df_tmp = df_tmp.iloc[0]
            data['hybrid_' + format_tag(teacher.split('__')[0] + '__' + format_tag(teacher.split('__')[1])) + '_progress'] = str(round(df_tmp['teacher_progress']))[:4]
    return data


def build_saved_alumn_data(db):
    data = {}
    structure = get_structures()
    questionary_id = 0
    db.fillna('', inplace=True)
    for questionary in ['presencial', 'hybrid', 'infrastructure', 'service']:
        for i in structure[questionary]:
            for j in range(0, structure[questionary][i]):
                if questionary in ['presencial', 'hybrid']:
                    try:
                        if questionary == 'presencial':
                            teachers_list = presencial(db)
                        else:
                            teachers_list = hybrid(db)
                        for teacher in teachers_list:
                            tag = '_' + format_tag(teacher.split('__')[0] + '__' + format_tag(teacher.split('__')[1]))
                            df_tmp = db.loc[(db['txt_teacher_name'] == teacher.split('__')[0]) & (db['txt_discipline_name'] == teacher.split('__')[1]) & (db['cod_questionary'] == questionary_id) & (db['cod_main_question'] == i) & (db['cod_inner_question'] == j)]
                            if not df_tmp.empty:
                                df_tmp.fillna('', inplace=True)
                                rate = df_tmp.loc[df_tmp.index.values[0], 'cod_inner_question_rate']
                                txt = df_tmp.loc[df_tmp.index.values[0], 'txt_inner_question_answer']
                                data['rate_' + questionary + '_' + str(i) + '_' + str(j) + tag] = str(rate)[:4]
                                data['txt_' + questionary + '_' + str(i) + '_' + str(j) + tag] = str(txt)
                    except Exception as ex:
                        warning(2, '|'.join(['teacher', 'build_saved_alumn_data']), str(ex))
                        # send_email('error: no teachers (def build_saved_alumn_data)<br>exception: ' + str(ex), 'navi@animaeducacao.com.br', '#ERRO NO MODULO AVALIACAO_INSTITUCIONAL')
                        pass
                else:
                    df_tmp = db.loc[(db['cod_questionary'] == questionary_id) & (db['cod_main_question'] == i) & (db['cod_inner_question'] == j)]
                    if not df_tmp.empty:
                        df_tmp.fillna('', inplace=True)
                        rate = df_tmp.loc[df_tmp.index.values[0], 'cod_inner_question_rate']
                        txt = df_tmp.loc[df_tmp.index.values[0], 'txt_inner_question_answer']
                        data['rate_' + questionary + '_' + str(i) + '_' + str(j)] = str(rate)[:4]
                        data['txt_' + questionary + '_' + str(i) + '_' + str(j)] = str(txt)
        questionary_id += 1
    return data


def get_alumn_data(params):
    try:
        cmd = "SELECT * FROM " + schema + ".Answers WHERE RA = {{RA}} AND COD_IES = {{COD_IES}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
        cmd = cmd.replace("{{COD_IES}}", str(params[1]))
        return get_connection().get_df(cmd)
    except:
        pass
    return False


def user_has_completed(params):
    try:
        cmd = "SELECT * FROM " + schema + ".Nps WHERE RA = {{RA}} AND COD_IES = {{COD_IES}}"

        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
        cmd = cmd.replace("{{COD_IES}}", str(params[1]))
        df = get_connection().get_df(cmd)
        df.fillna('', inplace=True)
        if (len(df) == 0) or (df.loc[0, 'cod_nps'] <= -1):
            return False
        return True
    except Exception as ex:
        print(ex)
        pass


def validate_answers_primary_keys(params):
    try:
        if params[4] in ['presencial', 'hybrid']:
            cmd = "SELECT * FROM " + schema + ".Answers WHERE RA = {{RA}} AND COD_IES = {{COD_IES}} AND COD_QUESTIONARY = {{COD_QUESTIONARY}} AND COD_MAIN_QUESTION = {{COD_MAIN_QUESTION}} AND COD_INNER_QUESTION = {{COD_INNER_QUESTION}} AND TXT_TEACHER_NAME = {{TXT_TEACHER_NAME}}"
            cmd = cmd.replace("'", '')
            cmd = cmd.replace('"', '')
            cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
            cmd = cmd.replace("{{COD_IES}}", str(params[1]))
            cmd = cmd.replace("{{COD_QUESTIONARY}}", str(params[3]))
            cmd = cmd.replace("{{COD_MAIN_QUESTION}}", str(params[5]))
            cmd = cmd.replace("{{COD_INNER_QUESTION}}", str(params[6]))
            cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "'" + str(params[7]) + "'")
        else:
            cmd = "SELECT * FROM " + schema + ".Answers WHERE RA = {{RA}} AND COD_IES = {{COD_IES}} AND COD_QUESTIONARY = {{COD_QUESTIONARY}} AND COD_MAIN_QUESTION = {{COD_MAIN_QUESTION}} AND COD_INNER_QUESTION = {{COD_INNER_QUESTION}}"
            cmd = cmd.replace("'", '')
            cmd = cmd.replace('"', '')
            cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
            cmd = cmd.replace("{{COD_IES}}", str(params[1]))
            cmd = cmd.replace("{{COD_QUESTIONARY}}", str(params[3]))
            cmd = cmd.replace("{{COD_MAIN_QUESTION}}", str(params[5]))
            cmd = cmd.replace("{{COD_INNER_QUESTION}}", str(params[6]))
        df = get_connection().get_df(cmd)
        if df.empty:
            return True
        return False
    except:
        pass
    return False


def validate_nps_primary_keys(params):
    try:
        cmd = "SELECT * FROM " + schema + ".Nps " \
              "WHERE " \
              "RA = {{RA}} AND COD_IES = {{COD_IES}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
        cmd = cmd.replace("{{COD_IES}}", str(params[1]))
        df = get_connection().get_df(cmd)
        if df.empty:
            return True
        return False
    except:
        pass
    return False


def update_nps(params):
    cmd = "UPDATE " + schema + ".Nps SET COD_NPS = {{COD_NPS}}, TXT_REASON = {{TXT_REASON}}, TXT_COMMENT = {{TXT_COMMENT}}, DATE_UPDATE = {{DATE_UPDATE}}, PLATAFORM = {{PLATAFORM}} " \
          "WHERE " \
          "RA = {{RA}} AND COD_IES = {{COD_IES}} AND TXT_IES = {{TXT_IES}}"
    cmd = cmd.replace("'", '')
    cmd = cmd.replace('"', '')
    cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
    cmd = cmd.replace("{{COD_IES}}", str(params[1]))
    cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]) + "'")
    cmd = cmd.replace("{{DATE_UPDATE}}", 'now()')
    cod_nps = str(params[3])
    txt_reason = str(params[4])
    txt_comment = str(params[5])
    # if cod_nps == 'undefined':
    #     cod_nps = -1
    # if txt_reason == 'undefined':
    #     txt_reason = ''
    # if txt_comment == 'undefined':
    #     txt_comment = ''
    cmd = cmd.replace("{{COD_NPS}}", str(cod_nps))
    cmd = cmd.replace("{{TXT_REASON}}", "'" + str(txt_reason) + "'")
    cmd = cmd.replace("{{TXT_COMMENT}}", "'" + str(txt_comment) + "'")
    cmd = cmd.replace("{{PLATAFORM}}", "'" + str(params[6]) + "'")
    # print(cmd)
    get_connection().execute(cmd)


def validate_progress_primary_keys(params):
    try:
        cmd = "SELECT * FROM " + schema + ".Progress " \
              "WHERE " \
              "RA = {{RA}} AND COD_IES = {{COD_IES}} AND TXT_TEACHER_NAME = {{TXT_TEACHER_NAME}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
        cmd = cmd.replace("{{COD_IES}}", str(params[1]))
        cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "'" + str(params[3]) + "'")
        df = get_connection().get_df(cmd)
        if df.empty:
            return True
        return False
    except:
        pass
    return False


def update_progress(params):
    cmd = "UPDATE " + schema + ".Progress SET TEACHER_PROGRESS = {{TEACHER_PROGRESS}}, INFRASTRUCTURE_PROGRESS = {{INFRASTRUCTURE_PROGRESS}}, SERVICE_PROGRESS = {{SERVICE_PROGRESS}}, TOTAL_PROGRESS = {{TOTAL_PROGRESS}} " \
          "WHERE " \
          "TXT_TEACHER_NAME = {{TXT_TEACHER_NAME}} AND RA = {{RA}} AND COD_IES = {{COD_IES}} AND TXT_IES = {{TXT_IES}}"
    cmd = cmd.replace("'", '')
    cmd = cmd.replace('"', '')
    cmd = cmd.replace("{{RA}}", "'" + str(params[0]) + "'")
    cmd = cmd.replace("{{COD_IES}}", str(params[1]))
    cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]) + "'")
    cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "'" + str(params[3]) + "'")
    cmd = cmd.replace("{{TEACHER_PROGRESS}}", str(params[4]))
    cmd = cmd.replace("{{INFRASTRUCTURE_PROGRESS}}", str(params[5]))
    cmd = cmd.replace("{{SERVICE_PROGRESS}}", str(params[6]))
    cmd = cmd.replace("{{TOTAL_PROGRESS}}", str(params[7]))
    # print(cmd)
    get_connection().execute(cmd)


def build_query_and_insert(table, all_params):
    cmd = ''
    if table == 'answers':
        cmd = "INSERT INTO " + schema + ".Answers (RA, COD_IES, TXT_IES, COD_QUESTIONARY, TXT_QUESTIONARY, COD_MAIN_QUESTION, COD_INNER_QUESTION, TXT_DISCIPLINE_NAME, TXT_DISCIPLINE_TYPE, TXT_TEACHER_NAME, TXT_TEACHER_TYPE, COD_INNER_QUESTION_RATE, TXT_INNER_QUESTION_ANSWER, DAT_REQUEST)" \
              " VALUES "
        for params in all_params:
            cmd += "({{RA}}, {{COD_IES}}, {{TXT_IES}}, {{COD_QUESTIONARY}}, {{TXT_QUESTIONARY}}, {{COD_MAIN_QUESTION}}, {{COD_INNER_QUESTION}}, {{TXT_DISCIPLINE_NAME}}, {{TXT_DISCIPLINE_TYPE}}, {{TXT_TEACHER_NAME}}, {{TXT_TEACHER_TYPE}},{{COD_INNER_QUESTION_RATE}}, {{TXT_INNER_QUESTION_ANSWER}}, {{DAT_REQUEST}})"
            if params[4] in ['presencial', 'hybrid']:
                cmd = cmd.replace("{{RA}}", "'" + str(params[0]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_IES}}", str(params[1]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_QUESTIONARY}}", str(params[3]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_QUESTIONARY}}", "'" + str(params[4]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_MAIN_QUESTION}}", str(params[5]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{COD_INNER_QUESTION}}", str(params[6]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "'" + str(params[7]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{TXT_DISCIPLINE_NAME}}", "'" + str(params[8]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{TXT_TEACHER_TYPE}}", "'" + str(params[9]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{TXT_DISCIPLINE_TYPE}}", "'" + str(params[10]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{DAT_REQUEST}}", 'now()')
                cmd = cmd.replace("{{COD_INNER_QUESTION_RATE}}", str(0))
                cmd = cmd.replace("{{TXT_INNER_QUESTION_ANSWER}}", "''")
            else:
                cmd = cmd.replace("{{RA}}", "'" + str(params[0]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_IES}}", str(params[1]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_QUESTIONARY}}", str(params[3]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_QUESTIONARY}}", "'" + str(params[4]).replace("'", '').replace('"', '') + "'")
                cmd = cmd.replace("{{COD_MAIN_QUESTION}}", str(params[5]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{COD_INNER_QUESTION}}", str(params[6]).replace("'", '').replace('"', ''))
                cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "''")
                cmd = cmd.replace("{{TXT_DISCIPLINE_NAME}}", "''")
                cmd = cmd.replace("{{TXT_TEACHER_TYPE}}", "''")
                cmd = cmd.replace("{{TXT_DISCIPLINE_TYPE}}", "''")
                cmd = cmd.replace("{{DAT_REQUEST}}", 'now()')
                cmd = cmd.replace("{{COD_INNER_QUESTION_RATE}}", str(0))
                cmd = cmd.replace("{{TXT_INNER_QUESTION_ANSWER}}", "''")
    elif table == 'progress':
        cmd = "INSERT INTO " + schema + ".Progress (RA, COD_IES, TXT_IES, TXT_TEACHER_NAME, TXT_DISCIPLINE_NAME, TXT_TEACHER_TYPE, TXT_DISCIPLINE_TYPE, TEACHER_PROGRESS, INFRASTRUCTURE_PROGRESS, SERVICE_PROGRESS, TOTAL_PROGRESS)" \
              " VALUES "
        for params in all_params:
            cmd += "({{RA}}, {{COD_IES}}, {{TXT_IES}}, {{TXT_TEACHER_NAME}}, {{TXT_DISCIPLINE_NAME}}, {{TXT_TEACHER_TYPE}}, {{TXT_DISCIPLINE_TYPE}}, {{TEACHER_PROGRESS}}, {{INFRASTRUCTURE_PROGRESS}}, {{SERVICE_PROGRESS}}, {{TOTAL_PROGRESS}})"
            cmd = cmd.replace("{{RA}}", "'" + str(params[0]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{COD_IES}}", str(params[1]).replace("'", '').replace('"', ''))
            cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{TXT_TEACHER_NAME}}", "'" + str(params[3]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{TXT_DISCIPLINE_NAME}}", "'" + str(params[4]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{TXT_TEACHER_TYPE}}", "'" + str(params[5]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{TXT_DISCIPLINE_TYPE}}", "'" + str(params[6]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{TEACHER_PROGRESS}}", str(0))
            cmd = cmd.replace("{{INFRASTRUCTURE_PROGRESS}}", str(0))
            cmd = cmd.replace("{{SERVICE_PROGRESS}}", str(0))
            cmd = cmd.replace("{{TOTAL_PROGRESS}}", str(0))
    elif table == 'nps':
        cmd = "INSERT INTO " + schema + ".Nps (RA, COD_IES, TXT_IES, COD_NPS, TXT_REASON, TXT_COMMENT, DATE_START, PLATAFORM)" \
              " VALUES "
        for params in all_params:
            cmd += "({{RA}}, {{COD_IES}}, {{TXT_IES}}, {{COD_NPS}}, {{TXT_REASON}}, {{TXT_COMMENT}}, {{DATE_START}}, {{PLATAFORM}})"
            cmd = cmd.replace("{{RA}}", "'" + str(params[0]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{COD_IES}}", str(params[1]).replace("'", '').replace('"', ''))
            cmd = cmd.replace("{{TXT_IES}}", "'" + str(params[2]).replace("'", '').replace('"', '') + "'")
            cmd = cmd.replace("{{COD_NPS}}", str(-1))
            cmd = cmd.replace("{{TXT_REASON}}", "''")
            cmd = cmd.replace("{{TXT_COMMENT}}", "''")
            cmd = cmd.replace("{{DATE_START}}", "now()")
            cmd = cmd.replace("{{PLATAFORM}}", "'" + str(params[3]) + "'")
    cmd = cmd.replace(')(', '), (')
    insert(cmd)


def update_answers(params):
    if params[8] not in ['infrastructure', 'service']:
        cmd = "UPDATE " + schema + ".Answers SET COD_INNER_QUESTION_RATE = {{RATE}}, TXT_INNER_QUESTION_ANSWER = {{ANSWER}}, DAT_RESPONSE = {{DAT_RESPONSE}} " \
              "WHERE " \
              "TXT_TEACHER_NAME = {{TEACHER}} AND TXT_DISCIPLINE_NAME = {{TXT_DISCIPLINE_NAME}} AND RA = {{RA}} AND COD_IES = {{COD_IES}} AND TXT_IES = {{TXT_IES}} AND COD_QUESTIONARY = {{COD_QUESTIONARY}} AND COD_MAIN_QUESTION = {{COD_MAIN_QUESTION}} AND COD_INNER_QUESTION = {{COD_INNER_QUESTION}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace('{{RATE}}', str(params[0]).replace('undefined', '0'))
        cmd = cmd.replace('{{TEACHER}}', "'" + str(params[1]) + "'")
        cmd = cmd.replace('{{TXT_DISCIPLINE_NAME}}', "'" + str(params[2]) + "'")
        cmd = cmd.replace('{{ANSWER}}', "'" + str(params[3] + "'").replace('undefined', ''))
        cmd = cmd.replace('{{DAT_RESPONSE}}', 'now()')
        cmd = cmd.replace('{{RA}}', "'" + str(params[4]) + "'")
        cmd = cmd.replace('{{COD_IES}}', str(params[5]))
        cmd = cmd.replace('{{TXT_IES}}', "'" + str(params[6]) + "'")
        cmd = cmd.replace('{{COD_QUESTIONARY}}', str(params[7]))
        cmd = cmd.replace('{{COD_MAIN_QUESTION}}', str(params[8]))
        cmd = cmd.replace('{{COD_INNER_QUESTION}}', str(params[9]))
    else:
        cmd = "UPDATE " + schema + ".Answers SET COD_INNER_QUESTION_RATE = {{RATE}}, TXT_INNER_QUESTION_ANSWER = {{ANSWER}}, DAT_RESPONSE = {{DAT_RESPONSE}} " \
              "WHERE " \
              "RA = {{RA}} AND COD_IES = {{COD_IES}} AND TXT_IES = {{TXT_IES}} AND COD_QUESTIONARY = {{COD_QUESTIONARY}} AND COD_MAIN_QUESTION = {{COD_MAIN_QUESTION}} AND COD_INNER_QUESTION = {{COD_INNER_QUESTION}}"
        cmd = cmd.replace("'", '')
        cmd = cmd.replace('"', '')
        cmd = cmd.replace('{{RATE}}', str(params[0]).replace('undefined', '0'))
        cmd = cmd.replace('{{ANSWER}}', "'" + str(params[1] + "'").replace('undefined', ''))
        cmd = cmd.replace('{{DAT_RESPONSE}}', 'now()')
        cmd = cmd.replace('{{RA}}', "'" + str(params[2]) + "'")
        cmd = cmd.replace('{{COD_IES}}', str(params[3]))
        cmd = cmd.replace('{{TXT_IES}}', "'" + str(params[4]) + "'")
        cmd = cmd.replace('{{COD_QUESTIONARY}}', str(params[5]))
        cmd = cmd.replace('{{COD_MAIN_QUESTION}}', str(params[6]))
        cmd = cmd.replace('{{COD_INNER_QUESTION}}', str(params[7]))
    # print(cmd)
    get_connection().execute(cmd)


def format_tag(value):
    import unidecode
    return unidecode.unidecode(str(value).replace(' ', '_').replace('.', '').replace(',', '').replace(':', '').replace(';', '').replace('(', '').replace(')', '').replace('/', '').replace('\\', '').lower())


def get_connection():
    #return RedshiftConnection('dev_andrei')
    return MySQLConnection('andrei_mastro')
    #return MySQLConnection('avaliacao')


def create_tables():
    tables_headers = {
        'table_questions': {
            'table_headers': [
                'cod_questionary', 'txt_questionary', 'cod_main_question', 'txt_main_question', 'cod_inner_question', 'txt_inner_question'
            ],
            'column_types': [
                'INT',  'VARCHAR(1000)', 'INT', 'VARCHAR(1000)', 'INT', 'VARCHAR(1000)'
            ],
            'table_name':
                'Questions'
        },
        'table_answers': {
            'table_headers': [
                'ra', 'cod_ies', 'txt_ies', 'cod_questionary', 'txt_questionary', 'cod_main_question', 'cod_inner_question', 'cod_inner_question_rate', 'txt_discipline_name', 'txt_discipline_type', 'txt_teacher_name', 'txt_teacher_type', 'txt_inner_question_answer', 'dat_request', 'dat_response'
            ],
            'column_types': [
                'VARCHAR(1000) NOT NULL', 'INT', 'VARCHAR(1000)', 'INT', 'VARCHAR(1000)', 'INT', 'INT', 'INT', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'DATETIME', 'DATETIME'
            ],
            'table_name':
                'Answers'
        },
        'table_progress': {
            'table_headers': [
                'ra', 'cod_ies', 'txt_ies', 'txt_discipline_name', 'txt_discipline_type', 'txt_teacher_name', 'txt_teacher_type', 'teacher_progress', 'infrastructure_progress', 'service_progress', 'total_progress'
            ],
            'column_types': [
                'VARCHAR(1000) NOT NULL', 'INT', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'INT', 'INT', 'INT', 'INT'
            ],
            'table_name':
                'Progress'
        },
        'table_nps': {
            'table_headers': [
                'ra', 'cod_ies', 'txt_ies', 'cod_nps', 'txt_reason', 'txt_comment', 'plataform', 'date_start', 'date_update'
            ],
            'column_types': [
                'VARCHAR(1000) NOT NULL', 'INT', 'VARCHAR(1000)', 'INT', 'VARCHAR(1000)', 'VARCHAR(1000)', 'VARCHAR(1000)', 'DATETIME', 'DATETIME'
            ],
            'table_name':
                'Nps'
        }
    }

    cmd = 'CREATE TABLE IF NOT EXISTS ' + schema + '.' + tables_headers['table_questions']['table_name'] + '(ID INT AUTO_INCREMENT,' + \
          tables_headers['table_questions']['table_headers'][0] + ' ' + tables_headers['table_questions']['column_types'][0] + ', ' + \
          tables_headers['table_questions']['table_headers'][1] + ' ' + tables_headers['table_questions']['column_types'][1] + ', ' + \
          tables_headers['table_questions']['table_headers'][2] + ' ' + tables_headers['table_questions']['column_types'][2] + ', ' + \
          tables_headers['table_questions']['table_headers'][3] + ' ' + tables_headers['table_questions']['column_types'][3] + ', ' + \
          tables_headers['table_questions']['table_headers'][4] + ' ' + tables_headers['table_questions']['column_types'][4] + ', ' + \
          tables_headers['table_questions']['table_headers'][5] + ' ' + tables_headers['table_questions']['column_types'][5] + ', ' \
          'KEY id (id))'
    get_connection().execute(cmd)

    cmd = 'CREATE TABLE IF NOT EXISTS ' + schema + '.' + tables_headers['table_answers']['table_name'] + '(ID INT AUTO_INCREMENT,' + \
          tables_headers['table_answers']['table_headers'][0] + ' ' + tables_headers['table_answers']['column_types'][0] + ', ' + \
          tables_headers['table_answers']['table_headers'][1] + ' ' + tables_headers['table_answers']['column_types'][1] + ', ' + \
          tables_headers['table_answers']['table_headers'][2] + ' ' + tables_headers['table_answers']['column_types'][2] + ', ' + \
          tables_headers['table_answers']['table_headers'][3] + ' ' + tables_headers['table_answers']['column_types'][3] + ', ' + \
          tables_headers['table_answers']['table_headers'][4] + ' ' + tables_headers['table_answers']['column_types'][4] + ', ' + \
          tables_headers['table_answers']['table_headers'][5] + ' ' + tables_headers['table_answers']['column_types'][5] + ', ' + \
          tables_headers['table_answers']['table_headers'][6] + ' ' + tables_headers['table_answers']['column_types'][6] + ', ' + \
          tables_headers['table_answers']['table_headers'][7] + ' ' + tables_headers['table_answers']['column_types'][7] + ', ' + \
          tables_headers['table_answers']['table_headers'][8] + ' ' + tables_headers['table_answers']['column_types'][8] + ', ' + \
          tables_headers['table_answers']['table_headers'][9] + ' ' + tables_headers['table_answers']['column_types'][9] + ', ' + \
          tables_headers['table_answers']['table_headers'][10] + ' ' + tables_headers['table_answers']['column_types'][10] + ', ' + \
          tables_headers['table_answers']['table_headers'][11] + ' ' + tables_headers['table_answers']['column_types'][11] + ', ' + \
          tables_headers['table_answers']['table_headers'][12] + ' ' + tables_headers['table_answers']['column_types'][12] + ', ' + \
          tables_headers['table_answers']['table_headers'][13] + ' ' + tables_headers['table_answers']['column_types'][13] + ', ' + \
          tables_headers['table_answers']['table_headers'][14] + ' ' + tables_headers['table_answers']['column_types'][14] + ', ' + \
          'PRIMARY KEY (id, RA, COD_IES))'
    get_connection().execute(cmd)

    cmd = 'CREATE TABLE IF NOT EXISTS ' + schema + '.' + tables_headers['table_progress']['table_name'] + '(ID INT AUTO_INCREMENT,' + \
          tables_headers['table_progress']['table_headers'][0] + ' ' + tables_headers['table_progress']['column_types'][0] + ', ' + \
          tables_headers['table_progress']['table_headers'][1] + ' ' + tables_headers['table_progress']['column_types'][1] + ', ' + \
          tables_headers['table_progress']['table_headers'][2] + ' ' + tables_headers['table_progress']['column_types'][2] + ', ' + \
          tables_headers['table_progress']['table_headers'][3] + ' ' + tables_headers['table_progress']['column_types'][3] + ', ' + \
          tables_headers['table_progress']['table_headers'][4] + ' ' + tables_headers['table_progress']['column_types'][4] + ', ' + \
          tables_headers['table_progress']['table_headers'][5] + ' ' + tables_headers['table_progress']['column_types'][5] + ', ' + \
          tables_headers['table_progress']['table_headers'][6] + ' ' + tables_headers['table_progress']['column_types'][6] + ', ' + \
          tables_headers['table_progress']['table_headers'][7] + ' ' + tables_headers['table_progress']['column_types'][7] + ', ' + \
          tables_headers['table_progress']['table_headers'][8] + ' ' + tables_headers['table_progress']['column_types'][8] + ', ' + \
          tables_headers['table_progress']['table_headers'][9] + ' ' + tables_headers['table_progress']['column_types'][9] + ', ' + \
          tables_headers['table_progress']['table_headers'][10] + ' ' + tables_headers['table_progress']['column_types'][10] + ', ' + \
          'PRIMARY KEY (id, RA, COD_IES))'
    get_connection().execute(cmd)

    cmd = 'CREATE TABLE IF NOT EXISTS ' + schema + '.' + tables_headers['table_nps']['table_name'] + '(ID INT AUTO_INCREMENT,' + \
          tables_headers['table_nps']['table_headers'][0] + ' ' + tables_headers['table_nps']['column_types'][0] + ', ' + \
          tables_headers['table_nps']['table_headers'][1] + ' ' + tables_headers['table_nps']['column_types'][1] + ', ' + \
          tables_headers['table_nps']['table_headers'][2] + ' ' + tables_headers['table_nps']['column_types'][2] + ', ' + \
          tables_headers['table_nps']['table_headers'][3] + ' ' + tables_headers['table_nps']['column_types'][3] + ', ' + \
          tables_headers['table_nps']['table_headers'][4] + ' ' + tables_headers['table_nps']['column_types'][4] + ', ' + \
          tables_headers['table_nps']['table_headers'][5] + ' ' + tables_headers['table_nps']['column_types'][5] + ', ' + \
          'PRIMARY KEY (id, RA, COD_IES))'
    get_connection().execute(cmd)


def drop_tables(params):
    #cmd = 'DELETE FROM ' + schema + '.' + str(params['table'] + ' WHERE RA IN ("131913747", "114112220", "121920019", "319128279", "171920024", "114112220", "201412782", "519120910", "51920230", "51920113", "51920231", "201300554", "819154388")')
    cmd = 'DELETE FROM ' + schema + '.' + str(params['table'] + ' WHERE RA = "818136643"')
    get_connection().execute(cmd)
    return True


def select(params):
    #cmd = 'SELECT * FROM ' + schema + '.' + str(params['table'] + ' WHERE TXT_DISCIPLINE_NAME LIKE "%TBLSAI%"')
    cmd = 'SELECT * FROM ' + schema + '.' + str(params['table'] + ' WHERE RA = "332321"')
    res = get_connection().get_df(cmd)
    if params['table'] == 'Answers':
        res.fillna('', inplace=True)
    if params['table'] == 'Progress':
        res.fillna(0, inplace=True)
    print(res)
    return res


def insert(cmd):
    get_connection().execute(cmd)


def get_main_questions():
    return [
        'E o que dizer dos(as) seus(suas) professores(as)! Qual o seu nível de satisfação em relação à(às):',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'E o que dizer dos(as) seus(suas) professores(as) das disciplinas online! Qual o seu nível de satisfação em relação à(às):',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'Vamos falar um pouco de Infraestrutura. Qual é o seu nível de satisfação em relação aos seguintes itens:',
        'E sobre sistemas? O que você tem a dizer?',
        'E aí: dos itens que você avaliou melhor, o que chama a sua atenção?',
        'Dos que não estão ainda indo bem, o que você acha que pode melhorar?',
        'Antes de tudo, conta pra gente: Qual é o seu nível de satisfação em relação à(ao):',
        'Queremos saber o que você acha do seu curso {NA} {SIGLAINSTITUICAOAVALIACAO}! Em relação às seguintes afirmações, o quanto você concorda com:',
        'Um primeiro passo na sua vida profissional...',
        '...e qual o seu nível de satisfação em relação:',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'E agora, fala pra gente: quais são os pontos mais bacanas oferecidos {PELA} {SIGLAINSTITUICAOAVALIACAO} para ajudar você no preparo para o mercado de trabalho?',
        '...e que pontos você acha que ainda dá para melhorar?',
        'Sobre o atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}, qual o seu nível de satisfação em relação à (às):',
        'E, de novo, queremos ouvir você: Quais são os pontos fortes do atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}?',
        '...e que pontos você acha que podem ser melhorados?',
        'E, resumindo: ...numa escala de 0 a 10, quanto você indicaria {A} {SIGLAINSTITUICAOAVALIACAO} para um(a) amigo(a)?',
        'O que te levou a nos dar esta nota?'
    ]


def get_questionary_name():
    return [
        'presencial',
        'hybrid',
        'infraestrutura',
        'service',
        'nps'
    ]


def get_all_questions():
    return [
        '0|0|0|Qualificação dos(as) professores(as)',
        '0|0|1|Estratégias didáticas utilizadas pelos(as) professores(as)',
        '0|0|2|Forma com que os professores se relacionam com os alunos',
        '0|1|0|As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
        '0|1|1|As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as)',
        '0|1|2|Os(as) professores(as) apresentam disponibilidade (presencial ou à distância) para atender você fora do horário das aulas',
        '0|1|3|Os(as) professores(as) demonstram domínio dos conteúdos abordados nas disciplinas',
        '0|1|4|Os(as) professores(as) incentivam você a ir além do que foi dado em sala de aula',
        '0|1|5|Os(as) professores(as) demonstram interesse pelo seu sucesso',
        '1|2|0|Qualificação dos(as) professores(as)',
        '1|2|1|Estratégias didáticas utilizadas pelos(as) professores(as)',
        '1|2|2|Forma com que os professores se relacionam com os alunos',
        '1|3|0|As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
        '1|3|1|Os professores online e presencial conversam entre si para a preparação das aulas.',
        '1|3|2|Os conteúdos disponibilizados são atrativos e de qualidade.',
        '1|3|3|A plataforma iLang é intuitiva e de fácil utilização.',
        '1|3|4|Os(as) professores(as) utilizam atividades interativas nos encontros presenciais.',
        '1|3|5|As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as) .',
        '1|3|6|Os(as) professores(as) incentivam você a ir além do que foi proposto no conteúdo.',
        '1|3|7|Os(as) professores(as) demonstram interesse pelo seu sucesso.',
        '2|4|0|Áreas comuns/Convivência',
        '2|4|1|Salas de aula',
        '2|4|2|Biblioteca',
        '2|4|3|Copiadora/Impressoras',
        '2|4|4|Laboratórios de Informática',
        '2|4|5|Laboratórios específicos de seu curso',
        '2|4|6|Banheiros',
        '2|4|7|Acesso à internet/Wi-Fi',
        '2|5|0|Ulife',
        '2|5|1|Ulife - Alunos (Antigo Sol Aluno)',
        '2|5|2|Ulife - Sala Virtual ( Antigo Ilang)',
        '2|5|3|Ulife - Estágio e Empregos',
        '2|6|0|',
        '2|7|0|',
        '3|8|0|Qualidade e relevância dos conteúdos e competências trabalhadas no seu curso',
        '3|8|1|O número de colaboradores (as) para dar suporte a você (por exemplo: pessoal administrativo, atendimento)',
        '3|8|2|Qualidade dos colaboradores (as) que dão suporte a você (por exemplo: pessoal administrativo, atendimento)',
        '3|8|3|Trabalho do(a) coordenador(a) de curso',
        '3|9|0|O curso propicia experiências de aprendizagem inovadoras',
        '3|9|1|O curso contribui para o desenvolvimento de uma consciência ética para o seu exercício profissional',
        '3|9|2|O curso contribui para você ampliar sua capacidade de comunicação escrita',
        '3|9|3|O curso contribui para você ampliar sua capacidade de comunicação oral',
        '3|9|4|O curso promove interdisciplinaridade',
        '3|9|5|{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes superarem dificuldades relacionadas ao processo de aprendizagem',
        '3|9|6|As atividades acadêmicas desenvolvidas dentro e fora da sua sala de aula possibilitaram refletir, ampliar a convivência e promover o respeito à diversidade',
        '3|10|0|Você faz estágio atualmente?',
        '3|10|1|Você trabalha atualmente?',
        '3|10|2|O seu trabalho está relacionado à sua área de atuação?',
        '3|11|0|À aplicabilidade dos conteúdos ofertados no curso para a sua atuação profissional',
        '3|11|1|Às oportunidades que {A} {SIGLAINSTITUICAOAVALIACAO} oferece em relação a carreira, estágios e conhecimento sobre o mercado de trabalho',
        '3|12|0|O meu curso é bem visto por empresas e instituições que oferecem estágios na área',
        '3|12|1|A Central de Carreiras divulga os serviços que oferece.',
        '3|12|2|{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes realizarem intercâmbios fora do país.',
        '3|13|0|',
        '3|14|0|',
        '3|15|0|Clareza com que as informações são transmitidas {PELA} {SIGLAINSTITUICAOAVALIACAO}.',
        '3|15|1|Disponibilidade dos funcionários para tirar dúvidas administrativas/acadêmicas.',
        '3|15|2|Qualificação dos funcionários para tirar dúvidas administrativas/acadêmicas.',
        '3|16|0|',
        '3|17|0|',
        '4|18|0|0',
        '4|18|0|1',
        '4|18|0|2',
        '4|18|0|3',
        '4|18|0|4',
        '4|18|0|5',
        '4|18|0|6',
        '4|18|0|7',
        '4|18|0|8',
        '4|18|0|9',
        '4|18|0|10',
        '4|19|0|Docente',
        '4|19|0|Infraestrutura',
        '4|19|0|Serviços',
    ]


def get_inner_questions():
    return {
        0: {
            0: {
                0: 'Qualificação dos(as) professores(as)',
                1: 'Estratégias didáticas utilizadas pelos(as) professores(as)',
                2: 'Forma com que os professores se relacionam com os alunos',
            },
            1: {
                0: 'As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
                1: 'As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as)',
                2: 'Os(as) professores(as) apresentam disponibilidade (presencial ou à distância) para atender você fora do horário das aulas',
                3: 'Os(as) professores(as) demonstram domínio dos conteúdos abordados nas disciplinas',
                4: 'Os(as) professores(as) incentivam você a ir além do que foi dado em sala de aula',
                5: 'Os(as) professores(as) demonstram interesse pelo seu sucesso'
            },
        },
        1: {
            2: {
                0: 'Qualificação dos(as) professores(as)',
                1: 'Estratégias didáticas utilizadas pelos(as) professores(as)',
                2: 'Forma com que os professores se relacionam com os alunos'
            },
            3: {
                0: 'As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
                1: 'Os professores online e presencial conversam entre si para a preparação das aulas.',
                2: 'Os conteúdos disponibilizados são atrativos e de qualidade.',
                3: 'A plataforma iLang é intuitiva e de fácil utilização.',
                4: 'Os(as) professores(as) utilizam atividades interativas nos encontros presenciais.',
                5: 'As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as) .',
                6: 'Os(as) professores(as) incentivam você a ir além do que foi proposto no conteúdo.',
                7: 'Os(as) professores(as) demonstram interesse pelo seu sucesso.'
            },
        },
        2: {
            4: {
                0: 'Áreas comuns/Convivência',
                1: 'Salas de aula',
                2: 'Biblioteca',
                3: 'Copiadora/Impressoras',
                4: 'Laboratórios de Informática',
                5: 'Laboratórios específicos de seu curso',
                6: 'Banheiros',
                7: 'Acesso à internet/Wi-Fi',
            },
            5: {
                0: 'Ulife',
                1: 'Ulife | Alunos (Antigo Sol Aluno)',
                2: 'Ulife | Sala Virtual ( Antigo Ilang)',
                3: 'Ulife | Estágio e Empregos',
            },
            6: {
                0: '',
            },
            7: {
                0: '',
            },
        },
        3: {
            7: {
                0: 'Qualidade e relevância dos conteúdos e competências trabalhadas no seu curso',
                1: 'O número de colaboradores (as) para dar suporte a você (por exemplo: pessoal administrativo, atendimento)',
                2: 'Qualidade dos colaboradores (as) que dão suporte a você (por exemplo: pessoal administrativo, atendimento)',
                3: 'Trabalho do(a) coordenador(a) de curso'
            },
            8: {
                0: 'O curso propicia experiências de aprendizagem inovadoras',
                1: 'O curso contribui para o desenvolvimento de uma consciência ética para o seu exercício profissional',
                2: 'O curso contribui para você ampliar sua capacidade de comunicação escrita',
                3: 'O curso contribui para você ampliar sua capacidade de comunicação oral',
                4: 'O curso promove interdisciplinaridade',
                5: '{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes superarem dificuldades relacionadas ao processo de aprendizagem',
                6: 'As atividades acadêmicas desenvolvidas dentro e fora da sua sala de aula possibilitaram refletir, ampliar a convivência e promover o respeito à diversidade'
            },
            9: {
                0: 'Você faz estágio atualmente?',
                1: 'Você trabalha atualmente?',
                2: 'O seu trabalho está relacionado à sua área de atuação?'
            },
            10: {
                0: 'À aplicabilidade dos conteúdos ofertados no curso para a sua atuação profissional',
                1: 'Às oportunidades que {A} {SIGLAINSTITUICAOAVALIACAO} oferece em relação a carreira, estágios e conhecimento sobre o mercado de trabalho',
            },
            11: {
                0: 'O meu curso é bem visto por empresas e instituições que oferecem estágios na área',
                1: 'A Central de Carreiras divulga os serviços que oferece.',
                2: '{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes realizarem intercâmbios fora do país.',
            },
            12: {
                0: '',
            },
            13: {
                0: '',
            },
            14: {
                0: 'Clareza com que as informações são transmitidas {PELA} {SIGLAINSTITUICAOAVALIACAO}.',
                1: 'Disponibilidade dos funcionários para tirar dúvidas administrativas/acadêmicas.',
                2: 'Qualificação dos funcionários para tirar dúvidas administrativas/acadêmicas.'
            },
            15: {
                0: '',
            },
            16: {
                0: '',
            },
        }
    }


def insert_questions():
    for line in get_all_questions():
        params = line.split('|')
        cmd = "INSERT INTO " + schema + ".Questions " \
              "(cod_questionary, txt_questionary, cod_main_question, txt_main_question, cod_inner_question, txt_inner_question) " \
              "VALUES " \
              "(" + str(params[0]) + ", '" + get_questionary_name()[int(params[0])] + \
              "', " + str(params[1]) + ", '" + get_main_questions()[int(params[1])] + \
              "', " + str(params[2]) + ", '" + str(params[3]) + "')"
        # print(cmd)
        insert(cmd)


########drop_tables({'table': 'Questions'})
#drop_tables({'table': 'Answers'})
#drop_tables({'table': 'Progress'})
#drop_tables({'table': 'Nps'})
#create_tables()
#build_answers()
#insert_questions()
#select({'table': 'Questions'})
#df = select({'table': 'Answers'})
#df.drop('ID', axis=1, inplace=True)
#print(len(df))
#df.drop_duplicates(inplace=True)
#print(len(df))
#select({'table': 'Answers'})
#select({'table': 'Progress'})
#select({'table': 'Nps'})
# drop_tables({'table': 'Answers'})
# drop_tables({'table': 'Progress'})
# drop_tables({'table': 'Nps'})
#get_connection().execute('UPDATE ' + schema + '.Nps SET COD_NPS = -1, TXT_REASON = "" WHERE RA = "123123123123123"')