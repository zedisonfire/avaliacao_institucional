import pandas as pd
import time
import base64
from django.views.decorators.csrf import csrf_exempt
import sys
from django.template.defaultfilters import register
from django.shortcuts import render, HttpResponse
from django_user_agents.utils import get_user_agent
from .CONNECTORS import *
from .data import *
import json
import inspect
import os
from .WARNINGS import *


sys.path.append('D:\\NAVI Dropbox\\Andrei Mastrochirico\\CODE\\')


def get_connection():
    return MySQLConnection('andrei_mastro')


def insert(params):
    cmd = ''
    get_connection().execute(cmd)


def select(params):
    cmd = 'SELECT * FROM dev_andrei.' + params['table']
    return get_connection().get_df(cmd)


def get_headers():
    return ['Docente', 'Infraestrutura', 'Serviço']


def get_tags():
    return {'emoji': {'emoji_'},
            '': {}
            }


def replace_ies(string, ies):
    if ies == 'UNIBH':
        replacements = ['do', 'no', 'O', 'pelo', 'o', ies]
    else:
        replacements = ['da', 'na', 'A', 'pela', 'a', ies]
    return string.replace('{DA}', replacements[0]).replace('{NA}', replacements[1]).replace('{A_UPPER}', replacements[2]).replace('{PELA}', replacements[3]).replace('{A}', replacements[4]).replace('{SIGLAINSTITUICAOAVALIACAO}', replacements[5])


def get_main_questions():
    return [
        'E o que dizer dos(as) seus(suas) professores(as)! Qual o seu nível de satisfação em relação à(às):',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'E o que dizer dos(as) seus(suas) professores(as) das disciplinas online! Qual o seu nível de satisfação em relação à(às):',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'Vamos falar um pouco de Infraestrutura. Qual é o seu nível de satisfação em relação aos seguintes itens:',
        'E aí: dos itens que você avaliou melhor, o que chama a sua atenção?',
        'Dos que não estão ainda indo bem, o que você acha que pode melhorar?',
        'Antes de tudo, conta pra gente: Qual é o seu nível de satisfação em relação à(ao):',
        'Queremos saber o que você acha do seu curso {NA} {SIGLAINSTITUICAOAVALIACAO}! Em relação às seguintes afirmações, o quanto você concorda com:',
        'Um primeiro passo na sua vida profissional...',
        '...e qual o seu nível de satisfação em relação:',
        'Em relação às seguintes afirmações, o quanto você concorda com:',
        'E agora, fala pra gente: quais são os pontos mais bacanas oferecidos {PELA} {SIGLAINSTITUICAOAVALIACAO} para ajudar você no preparo para o mercado de trabalho?',
        '...e que pontos você acha que ainda dá para melhorar?',
        'Sobre o atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}, qual o seu nível de satisfação em relação à (às):',
        'E, de novo, queremos ouvir você: Quais são os pontos fortes do atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}?',
        '...e que pontos você acha que podem ser melhorados?',
    ]


def get_questionary_name():
    return [
        'presencial',
        'hybrid',
        'infraestrutura',
        'service'
    ]


def get_all_questions():
    return [
        '0|0|0|Qualificação dos(as) professores(as)',
        '0|0|1|Estratégias didáticas utilizadas pelos(as) professores(as)',
        '0|0|2|Forma com que os professores se relacionam com os alunos',
        '0|1|0|As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
        '0|1|1|As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as)',
        '0|1|2|Os(as) professores(as) apresentam disponibilidade (presencial ou à distância) para atender você fora do horário das aulas',
        '0|1|3|Os(as) professores(as) demonstram domínio dos conteúdos abordados nas disciplinas',
        '0|1|4|Os(as) professores(as) incentivam você a ir além do que foi dado em sala de aula',
        '0|1|5|Os(as) professores(as) demonstram interesse pelo seu sucesso',
        '1|2|0|Qualificação dos(as) professores(as)',
        '1|2|1|Estratégias didáticas utilizadas pelos(as) professores(as)',
        '1|2|2|Forma com que os professores se relacionam com os alunos',
        '1|3|0|As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
        '1|3|1|Os professores online e presencial conversam entre si para a preparação das aulas.',
        '1|3|2|Os conteúdos disponibilizados são atrativos e de qualidade.',
        '1|3|3|A plataforma iLang é intuitiva e de fácil utilização.',
        '1|3|4|Os(as) professores(as) utilizam atividades interativas nos encontros presenciais.',
        '1|3|5|As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as) .',
        '1|3|6|Os(as) professores(as) incentivam você a ir além do que foi proposto no conteúdo.',
        '1|3|7|Os(as) professores(as) demonstram interesse pelo seu sucesso.',
        '2|4|0|Áreas comuns/Convivência',
        '2|4|1|Salas de aula',
        '2|4|2|Biblioteca',
        '2|4|3|Copiadora/Impressoras',
        '2|4|4|Laboratórios de Informática',
        '2|4|5|Laboratórios específicos de seu curso',
        '2|4|6|Banheiros',
        '2|4|7|Acesso à internet/Wi-Fi',
        '2|5|0|',
        '2|6|0|',
        '3|7|0|Qualidade e relevância dos conteúdos e competências trabalhadas no seu curso',
        '3|7|1|O número de colaboradores (as) para dar suporte a você (por exemplo: pessoal administrativo, atendimento)',
        '3|7|2|Qualidade dos colaboradores (as) que dão suporte a você (por exemplo: pessoal administrativo, atendimento)',
        '3|7|3|Trabalho do(a) coordenador(a) de curso',
        '3|8|0|O curso propicia experiências de aprendizagem inovadoras',
        '3|8|1|O curso contribui para o desenvolvimento de uma consciência ética para o seu exercício profissional',
        '3|8|2|O curso contribui para você ampliar sua capacidade de comunicação escrita',
        '3|8|3|O curso contribui para você ampliar sua capacidade de comunicação oral',
        '3|8|4|O curso promove interdisciplinaridade',
        '3|8|5|{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes superarem dificuldades relacionadas ao processo de aprendizagem',
        '3|8|6|As atividades acadêmicas desenvolvidas dentro e fora da sua sala de aula possibilitaram refletir, ampliar a convivência e promover o respeito à diversidade',
        '3|9|0|Você faz estágio atualmente?',
        '3|9|1|Você trabalha atualmente?',
        '3|9|2|O seu trabalho está relacionado à sua área de atuação?',
        '3|10|0|À aplicabilidade dos conteúdos ofertados no curso para a sua atuação profissional',
        '3|10|1|Às oportunidades que {A} {SIGLAINSTITUICAOAVALIACAO} oferece em relação a carreira, estágios e conhecimento sobre o mercado de trabalho',
        '3|11|0|O meu curso é bem visto por empresas e instituições que oferecem estágios na área',
        '3|11|1|A Central de Carreiras divulga os serviços que oferece.',
        '3|11|2|{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes realizarem intercâmbios fora do país.',
        '3|12|0|',
        '3|13|0|',
        '3|14|0|Clareza com que as informações são transmitidas {PELA} {SIGLAINSTITUICAOAVALIACAO}.',
        '3|14|1|Disponibilidade dos funcionários para tirar dúvidas administrativas/acadêmicas.',
        '3|14|2|Qualificação dos funcionários para tirar dúvidas administrativas/acadêmicas.',
        '3|15|0|',
        '3|16|0|'
    ]


def get_data(db, ies):
    return {
        'default': {
            'teacher': {
                'presencial': {
                    'header':
                        'Docente',
                    'names':
                        presencial(db)
                        ,
                    'first_main_question': {
                        0: 'E o que dizer dos(as) seus(suas) professores(as)! Qual o seu nível de satisfação em relação à(às):'
                    },
                    'first_questions': {
                        0: 'Qualificação dos(as) professores(as)',
                        1: 'Estratégias didáticas utilizadas pelos(as) professores(as)',
                        2: 'Forma com que os professores se relacionam com os alunos'
                    },
                    'second_main_question': {
                        1: 'Em relação às seguintes afirmações, o quanto você concorda com:'
                    },
                    'second_questions': {
                        0: 'As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
                        1: 'As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as)',
                        2: 'Os(as) professores(as) apresentam disponibilidade (presencial ou à distância) para atender você fora do horário das aulas',
                        3: 'Os(as) professores(as) demonstram domínio dos conteúdos abordados nas disciplinas',
                        4: 'Os(as) professores(as) incentivam você a ir além do que foi dado em sala de aula',
                        5: 'Os(as) professores(as) demonstram interesse pelo seu sucesso'
                    }
                },
                'hybrid': {
                    'header': 'Docente',
                    'names':
                        hybrid(db),
                    'first_main_question': {
                        2: 'E o que dizer dos(as) seus(suas) professores(as) das disciplinas online! Qual o seu nível de satisfação em relação à(às):'
                    },
                    'first_questions': {
                        0: 'Qualificação dos(as) professores(as)',
                        1: 'Estratégias didáticas utilizadas pelos(as) professores(as)',
                        2: 'Forma com que os professores se relacionam com os alunos'
                    },
                    'second_main_question': {
                        3: 'Em relação às seguintes afirmações, o quanto você concorda com:'
                    },
                    'second_questions': {
                        0: 'As relações professor-aluno ao longo do curso estimulam você a estudar e aprender.',
                        1: 'Os professores online e presencial conversam entre si para a preparação das aulas.',
                        2: 'Os conteúdos disponibilizados são atrativos e de qualidade.',
                        3: 'A plataforma iLang é intuitiva e de fácil utilização.',
                        4: 'Os(as) professores(as) utilizam atividades interativas nos encontros presenciais.',
                        5: 'As avaliações da aprendizagem realizadas pelos(as) professores(as) são compatíveis com os conteúdos ou temas trabalhados por eles(as) .',
                        6: 'Os(as) professores(as) incentivam você a ir além do que foi proposto no conteúdo.',
                        7: 'Os(as) professores(as) demonstram interesse pelo seu sucesso.'
                    }
                },
                'pos': {

                },
            },
            'infrastructure': {
                'header': 'Infraestrutura Geral',
                'first_main_question': {
                        4: 'Vamos falar um pouco de Infraestrutura. Qual é o seu nível de satisfação em relação aos seguintes itens:'
                },
                'first_questions': {
                    0: 'Áreas comuns/Convivência',
                    1: 'Salas de aula',
                    2: 'Biblioteca',
                    3: 'Copiadora/Impressoras',
                    4: 'Laboratórios de Informática',
                    5: 'Laboratórios específicos de seu curso',
                    6: 'Banheiros',
                    7: 'Acesso à internet/Wi-Fi'
                },
                'second_main_question': {
                    5: 'E sobre sistemas? O que você tem a dizer?'
                },
                'second_questions': {
                    0: 'Ulife',
                    1: 'Ulife - Alunos (Antigo Sol Aluno)',
                    2: 'Ulife - Sala Virtual ( Antigo Ilang)',
                    3: 'Ulife - Estágio e Empregos'

                },
                'third_main_question': {
                    6: 'E aí: dos itens que você avaliou melhor, o que chama a sua atenção?'
                },
                'third_questions': {
                    0: ''
                },
                'fourth_main_question': {
                    7: 'Dos que não estão ainda indo bem, o que você acha que pode melhorar?'
                },
                'fourth_questions': {
                    0: ''
                },
            },
            'service': {
                'header': 'Serviços Gerais',
                'first_main_question': {
                    8: 'Antes de tudo, conta pra gente: Qual é o seu nível de satisfação em relação à(ao):'
                },
                'first_questions': {
                    0: 'Qualidade e relevância dos conteúdos e competências trabalhadas no seu curso',
                    1: 'O número de colaboradores (as) para dar suporte a você (por exemplo: pessoal administrativo, atendimento)',
                    2: 'Qualidade dos colaboradores (as) que dão suporte a você (por exemplo: pessoal administrativo, atendimento)',
                    3: 'Trabalho do(a) coordenador(a) de curso'
                },
                'second_main_question': {
                    9: replace_ies('Queremos saber o que você acha do seu curso {NA} {SIGLAINSTITUICAOAVALIACAO}! Em relação às seguintes afirmações, o quanto você concorda com:', ies)
                },
                'second_questions': {
                    0: 'O curso propicia experiências de aprendizagem inovadoras',
                    1: 'O curso contribui para o desenvolvimento de uma consciência ética para o seu exercício profissional',
                    2: 'O curso contribui para você ampliar sua capacidade de comunicação escrita',
                    3: 'O curso contribui para você ampliar sua capacidade de comunicação oral',
                    4: 'O curso promove interdisciplinaridade',
                    5: replace_ies('{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes superarem dificuldades relacionadas ao processo de aprendizagem', ies),
                    6: 'As atividades acadêmicas desenvolvidas dentro e fora da sua sala de aula possibilitaram refletir, ampliar a convivência e promover o respeito à diversidade'
                },
                'third_main_question': {
                    10: 'Um primeiro passo na sua vida profissional...'
                },
                'third_questions': {
                    0: 'Você faz estágio atualmente?',
                    1: 'Você trabalha atualmente?',
                    2: 'O seu trabalho está relacionado à sua área de atuação?'
                },
                'fourth_main_question': {
                    11: '...e qual o seu nível de satisfação em relação:'
                },
                'fourth_questions': {
                    0: 'À aplicabilidade dos conteúdos ofertados no curso para a sua atuação profissional',
                    1: replace_ies('Às oportunidades que {A} {SIGLAINSTITUICAOAVALIACAO} oferece em relação a carreira, estágios e conhecimento sobre o mercado de trabalho', ies)
                },
                'fifth_main_question': {
                    12: 'Em relação às seguintes afirmações, o quanto você concorda com:'
                },
                'fifth_questions': {
                    0: 'O meu curso é bem visto por empresas e instituições que oferecem estágios na área',
                    1: 'A Central de Carreiras divulga os serviços que oferece.',
                    2: replace_ies('{A_UPPER} {SIGLAINSTITUICAOAVALIACAO} oferece oportunidades para os estudantes realizarem intercâmbios fora do país.', ies)
                },
                'sixth_main_question': {
                    13: replace_ies('E agora, fala pra gente: quais são os pontos mais bacanas oferecidos {PELA} {SIGLAINSTITUICAOAVALIACAO} para ajudar você no preparo para o mercado de trabalho?', ies)
                },
                'sixth_questions': {
                    0: ''
                },
                'seventh_main_question': {
                    14: '...e que pontos você acha que ainda dá para melhorar?'
                },
                'seventh_questions': {
                    0: ''
                },
                'eigth_main_question': {
                    15: replace_ies('Sobre o atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}, qual o seu nível de satisfação em relação à (às):', ies)
                },
                'eigth_questions': {
                    0: replace_ies('Clareza com que as informações são transmitidas {PELA} {SIGLAINSTITUICAOAVALIACAO}.', ies),
                    1: 'Disponibilidade dos funcionários para tirar dúvidas administrativas/acadêmicas.',
                    2: 'Qualificação dos funcionários para tirar dúvidas administrativas/acadêmicas.'
                },
                'ninth_main_question': {
                    16: replace_ies('E, de novo, queremos ouvir você: Quais são os pontos fortes do atendimento {DA} {SIGLAINSTITUICAOAVALIACAO}?', ies)
                },
                'ninth_questions': {
                    0: ''
                },
                'tenty_main_question': {
                    17: '...e que pontos você acha que podem ser melhorados?'
                },
                'tenty_questions': {
                    0: ''
                }
            },
        },
        'nps': {
            'first_main_question': {
                18: 'E, resumindo:',
            },
            'first_questions': {
                0: replace_ies('...numa escala de 0 a 10, quanto você indicaria {A} {SIGLAINSTITUICAOAVALIACAO} para um(a) amigo(a)?', ies)
            },
            'second_main_question': {
                19: 'O que te levou a nos dar esta nota?'
            },
            'second_questions': {
                0: 'Docente',
                1: 'Infraestrutura',
                2: 'Serviços'
            },
            'grades': [
                0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10
            ]
        }
    }


def get_template():
    return {
        'desktop': {
            'home': {
                'USJT': 'usjt.html',
                'UNA': 'una.html',
                'UNIBH': 'unibh.html',
                'UNISOCIESC': 'unisociesc.html'
            },
            'done': {
                'USJT': 'has_completed_usjt.html',
                'UNA': 'has_completed_una.html',
                'UNIBH': 'has_completed_unibh.html',
                'UNISOCIESC': 'has_completed_unisociesc.html'
            },
            'error': {
                'USJT': 'error_usjt.html',
                'UNA': 'error_una.html',
                'UNIBH': 'error_unibh.html',
                'UNISOCIESC': 'error_unisociesc.html'
            }
        },
        'mobile': {
            'home': {
                'USJT': 'usjt_mobile.html',
                'UNA': 'una_mobile.html',
                'UNIBH': 'unibh_mobile.html',
                'UNISOCIESC': 'unisociesc_mobile.html'
            },
            'done': {
                'USJT': 'has_completed_usjt_mobile.html',
                'UNA': 'has_completed_una_mobile.html',
                'UNIBH': 'has_completed_unibh_mobile.html',
                'UNISOCIESC': 'has_completed_unisociesc_mobile.html'
            },
            'error': {
                'USJT': 'error_usjt_mobile.html',
                'UNA': 'error_una_mobile.html',
                'UNIBH': 'error_unibh_mobile.html',
                'UNISOCIESC': 'error_unisociesc_mobile.html'
            }
        }
    }


def parseBody(request):
    body = request.body.decode('utf-8')
    return json.loads(body, strict=False)


@csrf_exempt
@register.filter(name='format_title')
def format_title(value, replace=True):
    data = split_by_delimiter(value, '__')
    data[1] = crop_long_words(data[1].lstrip().rstrip())
    if replace:
        return format_teacher_name(data).replace('-', '')
    data[0] = crop_long_words(data[0].lstrip().rstrip())
    return format_teacher_name(data)


@csrf_exempt
@register.filter(name='is_empty')
def is_empty(value):
    return len(value)


@csrf_exempt
@register.filter(name='get_first_position')
def get_first_position(value):
    return format_title(value, False).split('-')[0]


@csrf_exempt
@register.filter(name='get_second_position')
def get_second_position(value):
    return format_title(value, False).split('-')[1]


@csrf_exempt
@register.filter(name='format_hover')
def format_hover(value):
    return format_teacher_name(split_by_delimiter(value, '__')).replace('-', ' ')


@csrf_exempt
@register.filter(name='format_tag')
def format_tag(value):
    import unidecode
    return unidecode.unidecode(str(value).replace(' ', '_').replace('.', '').replace(',', '').replace(':', '').replace(';', '').replace('(', '').replace(')', '').replace('/', '').replace('\\', '').lower())


@csrf_exempt
@register.filter(name='split_question')
def split_question(value, i):
    import unidecode
    return unidecode.unidecode(str(value).split('|||')[int(i)])


@csrf_exempt
@register.filter
def value_by_index(List, i):
    return str(List[int(i)])


@csrf_exempt
@register.filter
def index(value, i):
    return str(format_tag(value)) + '_' + str(i)


@csrf_exempt
@register.filter
def entry_num_array(List):
    return range(len(List))


@csrf_exempt
@register.filter(name='format_response')
def format_response(value):
    # print(value)
    return value


@csrf_exempt
def user_is_valid(params):
    if validate_user(params):
        return True
    return False


@csrf_exempt
def health(request):
    return HttpResponse()
    #return HttpResponse(os.environ['schema'] + ' ' + os.environ['host'] + ' ' + os.environ['user'] + ' ' + os.environ['pass'] + ' ' + os.environ['db'] + ' ' + os.environ['debug'])


@csrf_exempt
def home(request):
    try:
        user_agent = get_user_agent(request)
        if user_agent.is_mobile:
            template = 'mobile'
        else:
            template = 'desktop'
    except Exception as ex:
        warning(2, '|'.join(['error while validating if request is from mobile or desktop', 'home', request]), str(ex))
        # send_email('error: user_agent.is_mobile (def home)<br>exception: ' + str(ex), 'navi@animaeducacao.com.br', 'ERRO NO AVALIACAO_INSTITUCIONAL')
        template = 'desktop'
        pass
    ra = ''
    try:
        ra = request.GET.get('token')
        cod_ies = request.GET.get('id')
        ra = base64.b64decode(ra).decode("utf-8")
        cod_ies = base64.b64decode(cod_ies).decode("utf-8")
        ies = get_ies_name_by_id(cod_ies)

        try:
            if user_has_completed([ra,  cod_ies]):
                return render(request, get_template()[template]['done'][ies], {'ra': 'RA: ' + ra if bool(ra) else ''})
            student_data = {
                'ra': encrypt(ra),
                'cod_ies': encrypt(cod_ies),
                'ies': encrypt(ies)
            }
            structure = get_structures()
            questionary_id = 0
            presencial_teachers = presencial(base, ra, False)
            hybrid_teachers = hybrid(base, ra, False)
            db = get_alumn_data([ra, cod_ies])
            if db.empty:
                answers_params = list()
                progress_params = list()
                nps_params = list()
                # if ra + '|' + ies + '|' + str(cod_ies) not in ras_list:
                #     send_email('error: conjunto de ra|ies|cod_ies não está no file ras_codies_ies (def home)<br>ra: ' + str(ra) + '<br>ies: ' + str(ies) + '<br>cod_ies: ' + str(cod_ies), 'navi@animaeducacao.com.br', '#ERRO NO MODULO AVALIACAO_INSTITUCIONAL')
                #     return render(request, get_template()[template]['error'][ies])

                for questionary in ['presencial', 'hybrid', 'infrastructure', 'service']:
                    for i in structure[questionary]:
                        for j in range(0, structure[questionary][i]):
                            if questionary in ['presencial', 'hybrid']:
                                if questionary == 'presencial':
                                    teachers_list = presencial_teachers
                                else:
                                    teachers_list = hybrid_teachers
                                for teacher in teachers_list:
                                    params = [
                                        ra,
                                        cod_ies,
                                        ies,
                                        questionary_id,  # cod_questionary
                                        questionary,  # txt_questionary
                                        i,  # cod_main_question
                                        j,  # cod_inner_question
                                        teacher.split('__')[0],
                                        teacher.split('__')[1],
                                        teacher.split('__')[2],
                                        teacher.split('__')[3]
                                    ]
                                    answers_params.append(params)
                            else:
                                params = [
                                    ra,
                                    cod_ies,
                                    ies,
                                    questionary_id,  # cod_questionary
                                    questionary,  # txt_questionary
                                    i,  # cod_main_question
                                    j,  # cod_inner_question
                                ]
                                answers_params.append(params)
                    questionary_id += 1
                    if questionary in ['presencial', 'hybrid']:
                        if len(presencial_teachers) == 0 and len(hybrid_teachers) == 0:
                            if questionary == 'presencial':
                                params = [
                                    ra,
                                    cod_ies,
                                    ies,
                                    '',
                                    '',
                                    'PRESENCIAL',
                                    'PRESENCIAL'
                                ]
                            else:
                                params = [
                                    ra,
                                    cod_ies,
                                    ies,
                                    '',
                                    '',
                                    'ONLINE',
                                    'HYBRID'
                                ]
                            progress_params.append(params)
                        else:
                            if questionary == 'presencial':
                                teachers_list = presencial_teachers
                            else:
                                teachers_list = hybrid_teachers
                            for teacher in teachers_list:
                                params = [
                                    ra,
                                    cod_ies,
                                    ies,
                                    teacher.split('__')[0],
                                    teacher.split('__')[1],
                                    teacher.split('__')[2],
                                    teacher.split('__')[3]
                                ]
                                progress_params.append(params)
                params = [
                    ra,
                    cod_ies,
                    ies,
                    template
                ]
                nps_params.append(params)
                build_query_and_insert('answers', answers_params)
                build_query_and_insert('progress', progress_params)
                build_query_and_insert('nps', nps_params)
                db = get_alumn_data([ra, cod_ies])
                saved_alumn_data = build_saved_alumn_data(db)
                saved_progress_data = build_saved_progress_data([ra, cod_ies])
            else:
                presencial_teachers = presencial(base, ra, False)
                hybrid_teachers = hybrid(base, ra, False)
                db = validate_teachers(db, presencial_teachers, hybrid_teachers, [ra, cod_ies, ies])
                saved_alumn_data = build_saved_alumn_data(db)
                saved_progress_data = build_saved_progress_data([ra, cod_ies])
            data = get_data(db, ies)
            return render(
                request, get_template()[template]['home'][ies], {
                    'default_teacher': data['default']['teacher'],
                    'default_infrastructure': data['default']['infrastructure'],
                    'default_service': data['default']['service'],
                    'nps': data['nps'],
                    'student_data': student_data,
                    'saved_alumn_data': saved_alumn_data,
                    'saved_progress_data': saved_progress_data
                }
            )
        except Exception as ex:
            warning(2, '|'.join(['error while building data', 'home', 'ra: ' + ra, 'cod_ies: ' + cod_ies, 'ies: ' + ies]), str(ex))
            # send_email('error: construcao de dados (def home)<br>exception: ' + str(ex) + '<br>ra: ' + str(ra) + '<br>cod_ies: ' + str(cod_ies), 'navi@animaeducacao.com.br', '#ERRO NO MODULO AVALIACAO_INSTITUCIONAL')
            return render(request, get_template()[template]['error'][ies])
    except Exception as ex:
        warning(2, '|'.join(['error while checking request', 'home', 'request: ' + str(request)]), str(ex))
        # send_email('error: validacao user_agent (def home)<br>exception: ' + str(ex), 'navi@animaeducacao.com.br', '#ERRO NO MODULO AVALIACAO_INSTITUCIONAL')
        return render(request, get_template()[template]['error']['USJT'])


@csrf_exempt
#@register.filter(name='save')  ss
def save(request):
    ra = ''
    cod_ies = ''
    ies = ''
    try:
        #warning(0, '|'.join(['prints request def save', 'save', 'body: ' + str(request.body) + 'request: ' + str(request) + 'ra: ' +ra, 'cod_ies: ' + cod_ies, 'ies: ' + ies]))
        data = parseBody(request)
        ra = decrypt(data['ra'])
        cod_ies = decrypt(data['cod_ies'])
        ies = decrypt(data['ies'])
        structure = get_structures()
        questionary_id = 0
        presencial_teachers = presencial(base, ra, False)
        hybrid_teachers = hybrid(base, ra, False)
        for questionary in ['presencial', 'hybrid', 'infrastructure', 'service']:
            for i in structure[questionary]:
                for j in range(0, structure[questionary][i]):
                    if questionary in ['presencial', 'hybrid']:
                        try:
                            if questionary == 'presencial':
                                teachers_list = presencial_teachers
                            else:
                                teachers_list = hybrid_teachers
                            for teacher in teachers_list:
                                params = [
                                    data['rate_' + questionary + '_' + str(i) + '_' + str(j) + '_' + format_tag(teacher.split('__')[0] + '__' + teacher.split('__')[1])],
                                    teacher.split('__')[0],
                                    teacher.split('__')[1],
                                    data['txt_' + questionary + '_' + str(i) + '_' + str(j) + '_' + format_tag(teacher.split('__')[0] + '__' + teacher.split('__')[1])],
                                    ra,
                                    cod_ies,
                                    ies,
                                    questionary_id,  # cod_questionary
                                    i,  # cod_main_question
                                    j  # cod_inner_question
                                ]
                                update_answers(params)
                        except Exception as ex:
                            warning(2, '|'.join(['error while building teacher data to save', 'save', 'ra: ' +ra, 'cod_ies: ' + cod_ies, 'ies: ' + ies]), str(ex))
                            # send_email('error: no teachers (def save)<br>exception: ' + str(ex) + '<br>ra: ' + str(ra) + '<br>cod_ies: ' + str(cod_ies), 'navi@animaeducacao.com.br', '#ERRO NO MODULO AVALIACAO_INSTITUCIONAL')
                            pass
                    else:
                        params = [
                            data['rate_' + questionary + '_' + str(i) + '_' + str(j)] if data['rate_' + questionary + '_' + str(i) + '_' + str(j)] != None else '0',
                            data['txt_' + questionary + '_' + str(i) + '_' + str(j)],
                            ra,
                            cod_ies,
                            ies,
                            questionary_id,  # cod_questionary
                            i,  # cod_main_question
                            j,  # cod_inner_question
                            questionary
                        ]
                        update_answers(params)
            if questionary in ['presencial', 'hybrid']:
                if len(presencial_teachers) == 0 and len(hybrid_teachers) == 0:
                    params = [
                        ra,
                        cod_ies,
                        ies,
                        '',
                        0,
                        data['infrastructure_progress'],
                        data['service_progress'],
                        data['total_progress']
                    ]
                    update_progress(params)
                else:
                    if questionary == 'presencial':
                        teachers_list = presencial_teachers
                    else:
                        teachers_list = hybrid_teachers
                    for teacher in teachers_list:
                        params = [
                            ra,
                            cod_ies,
                            ies,
                            teacher.split('__')[0],
                            data[questionary + '_' + format_tag(teacher.split('__')[0] + '__' + teacher.split('__')[1]) + '_progress'],
                            data['infrastructure_progress'],
                            data['service_progress'],
                            data['total_progress']
                        ]
                        update_progress(params)
            questionary_id += 1
        params = [
            ra,
            cod_ies,
            ies,
            data['nps'],
            data['nps_reason'],
            data['nps_comment'],
            data['plataform']
        ]
        update_nps(params)
        return HttpResponse('true')
    except Exception as ex:
        warning(1, '|'.join(['error while saving data', 'save', 'ra: ' + ra, 'cod_ies: ' + cod_ies, 'ies: ' + ies]), str(ex))
        # send_email('error: save (def save)<br>exception: ' + str(ex), '<br>ra: ' + str(ra) + '<br>cod_ies: ' + str(cod_ies) + '<br>ies: ' + str(ies) + 'navi@animaeducacao.com.br', 'ERRO NO AVALIACAO_INSTITUCIONAL')
        return HttpResponse('error')


path = os.path.dirname(os.path.abspath(inspect.getfile(inspect.currentframe())))[:-9]
# base = pd.read_csv(path + 'AVALIACAO_INSTITUCIONAL_DADOSII.csv', sep=';', decimal=',', encoding='UTF-8', low_memory=False, error_bad_lines=False)
base = pd.read_csv(path + 'dados-ai-2019-2.csv', sep='|', decimal=',', encoding='LATIN-1', low_memory=False, error_bad_lines=False)
ras_list = open(path + 'ras_codies_ies.txt', 'r').readlines()
ras_list = [x.replace('\n', '') for x in ras_list]
